npm install -g wcm-design.tar.gz
npm install -g --unsafe-perm --no-optional dashboard.tar.gz
npm install -g nw
